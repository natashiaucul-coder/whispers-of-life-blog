import Head from 'next/head';
import Link from 'next/link';

export default function Layout({ children }) {
  return (
    <>
      <Head>
        <title>Whispers of Life</title>
        <meta name="description" content="Personal blog — catatan & puisi" />
      </Head>
      <header className="bg-white/80 sticky top-0 shadow-sm">
        <div className="max-w-4xl mx-auto px-6 py-4 flex items-center justify-between">
          <Link href="/"><a className="text-xl font-bold text-indigo-600">Whispers of Life</a></Link>
          <nav className="hidden md:flex gap-6 text-sm">
            <Link href="/"><a className="hover:text-indigo-600">Home</a></Link>
            <Link href="/about"><a className="hover:text-indigo-600">About</a></Link>
          </nav>
        </div>
      </header>
      <main className="max-w-4xl mx-auto px-6 py-10">{children}</main>
      <footer className="py-8 text-center text-sm text-gray-500">© 2025 Whispers of Life</footer>
    </>
  );
}
