---
title: "Senja yang Luruh"
date: "2025-09-28"
excerpt: "Renungan singkat tentang senja dan rindu yang lembut."
---

Senja menurunkan warna, dan aku menunggu dengan secangkir kopi.
Kata-kata datang seperti langkah kecil.
