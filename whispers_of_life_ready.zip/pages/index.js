import fs from 'fs';
import path from 'path';
import Link from 'next/link';
import matter from 'gray-matter';
import Layout from '../components/Layout';

export async function getStaticProps() {
  const postsDir = path.join(process.cwd(), 'posts');
  const files = fs.existsSync(postsDir) ? fs.readdirSync(postsDir).filter(f => f.endsWith('.md')) : [];
  const posts = files.map(filename => {
    const file = fs.readFileSync(path.join(postsDir, filename), 'utf-8');
    const { data } = matter(file);
    return {
      frontmatter: data,
      slug: filename.replace('.md', '')
    };
  }).sort((a,b) => new Date(b.frontmatter.date) - new Date(a.frontmatter.date));
  return { props: { posts } };
}

export default function Home({ posts }) {
  return (
    <Layout>
      <h1 className="text-3xl font-bold mb-4">Whispers of Life</h1>
      <p className="text-gray-600 mb-6">Catatan & puisi tentang kehidupan sehari-hari.</p>
      <section className="grid gap-6 md:grid-cols-2">
        {posts.map(({ slug, frontmatter }) => (
          <article key={slug} className="p-6 border rounded-lg hover:shadow">
            <h2 className="font-semibold text-lg"><Link href={`/posts/${slug}`}><a className="text-indigo-600">{frontmatter.title}</a></Link></h2>
            <p className="text-sm text-gray-500">{frontmatter.date}</p>
            {frontmatter.excerpt && <p className="mt-2 text-gray-600">{frontmatter.excerpt}</p>}
          </article>
        ))}
      </section>
    </Layout>
  );
}
