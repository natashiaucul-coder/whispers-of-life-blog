import fs from 'fs';
import path from 'path';
import matter from 'gray-matter';
import { marked } from 'marked';
import Layout from '../../components/Layout';

export async function getStaticPaths() {
  const postsDir = path.join(process.cwd(), 'posts');
  const files = fs.existsSync(postsDir) ? fs.readdirSync(postsDir).filter(f => f.endsWith('.md')) : [];
  const paths = files.map(f => ({ params: { slug: f.replace('.md','') } }));
  return { paths, fallback: false };
}

export async function getStaticProps({ params }) {
  const postsDir = path.join(process.cwd(), 'posts');
  const file = fs.readFileSync(path.join(postsDir, params.slug + '.md'), 'utf-8');
  const { data, content } = matter(file);
  return { props: { frontmatter: data, content } };
}

export default function Post({ frontmatter, content }) {
  return (
    <Layout>
      <h1 className="text-3xl font-bold mb-2">{frontmatter.title}</h1>
      <p className="text-sm text-gray-500">{frontmatter.date}</p>
      <article className="prose mt-6" dangerouslySetInnerHTML={{ __html: marked(content) }} />
    </Layout>
  );
}
