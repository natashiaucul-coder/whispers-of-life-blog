import Layout from '../components/Layout';

export default function About() {
  return (
    <Layout>
      <h1 className="text-2xl font-bold">About</h1>
      <p className="mt-4 text-gray-600">Ini adalah blog personal bernama Whispers of Life — tempat menulis catatan dan puisi sehari-hari.</p>
    </Layout>
  );
}
